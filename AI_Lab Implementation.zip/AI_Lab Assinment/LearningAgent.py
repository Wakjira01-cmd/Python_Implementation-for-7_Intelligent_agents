# Task 7: Learning Agent
# Agent records past performance and improves over time

room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B): ").upper()

environment = {"A": room_A, "B": room_B}
performance = 0
history = []

while "Dirty" in environment.values():
    if environment[location] == "Dirty":
        action = "SUCK"
        environment[location] = "Clean"
        performance += 10
    else:
        action = "MOVE"
        location = "B" if location == "A" else "A"
        performance -= 1
    
    # Record history
    history.append((location, action, performance))
    print(f"\nAgent Location: {location}, Action: {action}, Performance: {performance}")

print("\nFinal Environment:", environment)
print("Learning History:", history)