# Task 6: Utility-Based Agent
# Chooses actions with maximum utility
# Cleaning = +10, Moving = -2

room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B): ").upper()

environment = {"A": room_A, "B": room_B}
total_utility = 0

while "Dirty" in environment.values():
    print(f"\nAgent Location: {location}")
    
    if environment[location] == "Dirty":
        print("Action: SUCK (+10)")
        environment[location] = "Clean"
        total_utility += 10
    else:
        print("Action: MOVE (-2)")
        location = "B" if location == "A" else "A"
        total_utility -= 2

print("\nFinal Environment:", environment)
print("Total Utility:", total_utility)