# Name & ID: [Wakjira Berhanu,UGR/20996/16]
# Course: Introduction toArtificial Intelligence
# 3rd Year Computer Science
# Task 5: Goal-Based Agent
# Goal: All rooms must be clean (A, B, C)

room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
room_C = input("Enter state of Room C (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B/C): ").upper()

environment = {"A": room_A, "B": room_B, "C": room_C}

while "Dirty" in environment.values():
    print(f"\nAgent Location: {location}")
    print("Environment:", environment)
    
    if environment[location] == "Dirty":
        print("Action: SUCK")
        environment[location] = "Clean"
    else:
        # Move to next dirty room
        for room in environment:
            if environment[room] == "Dirty":
                print(f"Moving to room {room}")
                location = room
                break

print("\nGoal Achieved: All rooms clean.")
print("Final Environment:", environment)