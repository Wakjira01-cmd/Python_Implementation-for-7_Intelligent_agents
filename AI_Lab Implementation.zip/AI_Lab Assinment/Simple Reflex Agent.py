# Task 1: Simple Reflex Vacuum Cleaner Agent
# Name & ID: [Wakjira Berhanu,UGR/20996/16]
# Course: Artificial Intelligence
# 3rd Year Computer Science

# This agent acts based ONLY on the current percept (room cleanliness).

# --- User Input ---
room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B): ").upper()

# Environment dictionary
environment = {"A": room_A, "B": room_B}

# --- Simple Reflex Decision Function ---
def simple_reflex(location):
    if environment[location] == "Dirty":
        return "SUCK"
    else:
        return "MOVE_RIGHT" if location == "A" else "MOVE_LEFT"

# --- Simulation ---
print("\nInitial Environment:", environment)
action = simple_reflex(location)
print(f"Agent at {location} -> Action: {action}")

# Update environment after action
if action == "SUCK":
    environment[location] = "Clean"
else:
    location = "B" if location == "A" else "A"

print("Updated Environment:", environment)
print("Agent New Location:", location)