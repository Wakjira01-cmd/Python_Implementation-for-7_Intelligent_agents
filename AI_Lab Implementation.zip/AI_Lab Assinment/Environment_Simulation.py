# Name & ID: [Wakjira Berhanu,UGR/20996/16]
# Course: Introduction toArtificial Intelligence
# 3rd Year Computer Science

# Task 2: Agent and Environment Simulation
# This program simulates an environment with 2 rooms (A & B) and agent actions.

room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B): ").upper()
steps = int(input("Enter number of simulation steps: "))

environment = {"A": room_A, "B": room_B}

for step in range(steps):
    print(f"\n--- Step {step+1} ---")
    print("Agent Location:", location)
    print("Environment:", environment)
    
    if environment[location] == "Dirty":
        print("Action: SUCK")
        environment[location] = "Clean"
    else:
        if location == "A":
            print("Action: MOVE RIGHT")
            location = "B"
        else:
            print("Action: MOVE LEFT")
            location = "A"

print("\nFinal Environment:", environment)