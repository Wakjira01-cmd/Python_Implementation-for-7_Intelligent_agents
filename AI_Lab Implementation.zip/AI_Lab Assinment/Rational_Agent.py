# Name & ID: [Wakjira Berhanu,UGR/20996/16]
# Course: Introduction toArtificial Intelligence
# 3rd Year Computer Science

# Task 3: Rational Vacuum Cleaner Agent
# This agent selects actions to maximize performance measure.
# Performance: +10 for cleaning, -1 for moving.

room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B): ").upper()

environment = {"A": room_A, "B": room_B}
performance = 0

for step in range(4):
    print(f"\n--- Step {step+1} ---")
    print("Agent Location:", location)
    print("Environment:", environment)
    
    if environment[location] == "Dirty":
        print("Action: SUCK (+10)")
        environment[location] = "Clean"
        performance += 10
    else:
        print("Action: MOVE (-1)")
        location = "B" if location == "A" else "A"
        performance -= 1

print("\nFinal Environment:", environment)
print("Total Performance:", performance)