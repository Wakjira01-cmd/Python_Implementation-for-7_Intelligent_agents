# Task 4: Model-Based Vacuum Cleaner Agent
# Remembers the status of previously visited rooms (internal model)

room_A = input("Enter state of Room A (Clean/Dirty): ").capitalize()
room_B = input("Enter state of Room B (Clean/Dirty): ").capitalize()
location = input("Enter starting location (A/B): ").upper()

environment = {"A": room_A, "B": room_B}
model = {"A": None, "B": None}  # Internal memory

while "Dirty" in environment.values():
    # Update internal model
    model[location] = environment[location]
    print(f"\nAgent Location: {location}")
    print("Internal Model:", model)

    # Decide action
    if environment[location] == "Dirty":
        print("Action: SUCK")
        environment[location] = "Clean"
    else:
        print("Action: MOVE")
        location = "B" if location == "A" else "A"

print("\nAll rooms cleaned.")
print("Final Environment:", environment)